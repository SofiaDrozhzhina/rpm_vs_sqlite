﻿using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace rpm_sqlite;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private readonly TripContext _context = new TripContext();
    public MainWindow()
    {
        InitializeComponent();
        CmbFiltr.ItemsSource = _context.Transports.ToList();
        CmbFiltr.SelectedValuePath = "IdTransport";
        CmbFiltr.DisplayMemberPath = "Nazvanie";
        LoadData();
    }
    private void LoadData()
    {
        var trip = _context.Itogs
            .Include(c => c.IdPunktOtpravkiNavigation)
            .Include(c => c.IdPunktNaznachNavigation)
            .Include(c => c.IdTransportNavigation)
            .ToList();

        TripDataGrid.ItemsSource = trip;

    }


    private void BtnSearch_Click(object sender, RoutedEventArgs e)
    {
        if (TxtSearch.Text == "")
        {
            var trip = _context.Itogs
                   .Include(c => c.IdPunktOtpravkiNavigation)
                   .Include(c => c.IdPunktNaznachNavigation)
                   .Include(c => c.IdTransportNavigation)
                   .ToList();
            TripDataGrid.ItemsSource = trip;
        }
        else
        {
            var trip = _context.Itogs
                   .Include(c => c.IdPunktOtpravkiNavigation)
                   .Include(c => c.IdPunktNaznachNavigation)
                   .Include(c => c.IdTransportNavigation)
                   .Where(p => p.IdTransportNavigation.Nazvanie.Contains(TxtSearch.Text)).ToList();
            if (trip.Count == 0)
            {
                MessageBox.Show("Такого транспорта нет");
            }
            TripDataGrid.ItemsSource = trip;
        }
    }

    private void BtnSortUp_Click(object sender, RoutedEventArgs e)
    {
        var trip = _context.Itogs
                   .Include(c => c.IdPunktOtpravkiNavigation)
                   .Include(c => c.IdPunktNaznachNavigation)
                   .Include(c => c.IdTransportNavigation)
                   .OrderBy(p => p.Price).ToList();
        TripDataGrid.ItemsSource = trip;
    }

    private void BtnSortDown_Click(object sender, RoutedEventArgs e)
    {
        var trip = _context.Itogs
                   .Include(c => c.IdPunktOtpravkiNavigation)
                   .Include(c => c.IdPunktNaznachNavigation)
                   .Include(c => c.IdTransportNavigation)
                   .OrderByDescending(p => p.Price).ToList();
        TripDataGrid.ItemsSource = trip;
    }

    private void TripDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
       
    }

    private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (CmbFiltr.SelectedValue is int selectedTransportId)
        {
            var filteredTrips = _context.Itogs
                .Include(c => c.IdPunktOtpravkiNavigation)
                .Include(c => c.IdPunktNaznachNavigation)
                .Include(c => c.IdTransportNavigation)
                .Where(p => p.IdTransport == selectedTransportId)
                .ToList();

            TripDataGrid.ItemsSource = filteredTrips;
        }
    }
}